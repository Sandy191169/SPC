<!-- area_volume.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Area and Volume Calculator</title>
</head>
<body>

    <h1>Calculate Area and Volume</h1>
    <form method="post" action="results.php">
        <label for="radius">Enter Radius:</label>
        <input type="number" id="radius" name="radius" step="0.01" required><br><br>

        <label for="height">Enter Height (For Cylinder):</label>
        <input type="number" id="height" name="height" step="0.01" required><br><br>

        <input type="submit" name="calculate_area_volume" value="Calculate">
    </form>

</body>
</html>
