<!-- index.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arithmetic Operations</title>
</head>
<body>

    <h1>Simple Arithmetic Calculator</h1>
    <form action="result.php" method="post">
        <label for="num1">Enter first number:</label>
        <input type="number" id="num1" name="num1" required><br><br>

        <label for="num2">Enter second number:</label>
        <input type="number" id="num2" name="num2" required><br><br>

        <label>Select an operation:</label><br>
        <input type="radio" id="add" name="operation" value="add" checked>
        <label for="add">Add</label><br>

        <input type="radio" id="subtract" name="operation" value="subtract">
        <label for="subtract">Subtract</label><br>

        <input type="radio" id="multiply" name="operation" value="multiply">
        <label for="multiply">Multiply</label><br>

        <input type="radio" id="divide" name="operation" value="divide">
        <label for="divide">Divide</label><br><br>

        <input type="submit" value="Calculate">
    </form>

</body>
</html>
