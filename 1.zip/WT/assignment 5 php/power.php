<!-- power.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Power of a Number</title>
</head>
<body>

    <h1>Calculate Power</h1>
    <form method="post" action="">
        <label for="base">Enter Base Number:</label>
        <input type="number" id="base" name="base" required><br><br>

        <label for="exponent">Enter Exponent:</label>
        <input type="number" id="exponent" name="exponent" required><br><br>

        <input type="submit" name="calculate_power" value="Calculate Power">
    </form>

    <?php
    if (isset($_POST['calculate_power'])) {
        $base = (float)$_POST['base'];
        $exponent = (float)$_POST['exponent'];

        // Anonymous function to calculate power
        $power = function($base, $exponent) {
            return pow($base, $exponent);
        };

        // Display result
        echo "<p>Result: " . $power($base, $exponent) . "</p>";
    }
    ?>

</body>
</html>


