<!-- result.php -->
<?php
require 'arithmetic.php';

// Retrieve user inputs
$num1 = isset($_POST['num1']) ? (float)$_POST['num1'] : 0;
$num2 = isset($_POST['num2']) ? (float)$_POST['num2'] : 0;
$operation = isset($_POST['operation']) ? $_POST['operation'] : 'add';

// Perform the calculation
$result = calculate($num1, $num2, $operation);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>result</title>
</head>
<body>

    <h1>Calculation result</h1>
    <p>result: <?php echo $result; ?></p>
    <a href="index.php">Go back</a>

</body>
</html>
