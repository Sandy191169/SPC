<!-- interchange.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interchange Two Numbers</title>
</head>
<body>

    <h1>Interchange Two Numbers</h1>
    <form method="post" action="">
        <label for="num1">Enter First Number:</label>
        <input type="number" id="num1" name="num1" required><br><br>

        <label for="num2">Enter Second Number:</label>
        <input type="number" id="num2" name="num2" required><br><br>

        <input type="submit" name="interchange" value="Interchange">
    </form>

    <?php
    if (isset($_POST['interchange'])) {
        $num1 = (float)$_POST['num1'];
        $num2 = (float)$_POST['num2'];

        // Function to swap using call by reference
        function interchange(&$a, &$b) {
            $temp = $a;
            $a = $b;
            $b = $temp;
        }

        // Call the function
        interchange($num1, $num2);

        // Display result
        echo "<p>After interchange:<br>First Number: $num1<br>Second Number: $num2</p>";
    }
    ?>

</body>
</html>

