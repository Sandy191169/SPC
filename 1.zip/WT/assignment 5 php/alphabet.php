<!-- alphabets.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Alphabets</title>
</head>
<body>

    <h1>Display Alphabets Between Two Letters</h1>
    <form method="post" action="">
        <label for="start_alpha">Enter First Alphabet:</label>
        <input type="text" id="start_alpha" name="start_alpha" maxlength="1" pattern="[A-Za-z]" required><br><br>

        <label for="end_alpha">Enter Second Alphabet:</label>
        <input type="text" id="end_alpha" name="end_alpha" maxlength="1" pattern="[A-Za-z]" required><br><br>

        <input type="submit" name="display_alphabets" value="Display Alphabets">
    </form>

    <?php
    if (isset($_POST['display_alphabets'])) {
        $start_alpha = strtoupper($_POST['start_alpha']);
        $end_alpha = strtoupper($_POST['end_alpha']);

        // Function to display alphabets between two letters
        function displayAlphabets($start = 'A', $end = 'Z') {
            $start = strtoupper($start);
            $end = strtoupper($end);
            $alphabets = range($start, $end);
            return implode(", ", $alphabets);
        }

        // Display the result
        echo "<p>Alphabets between $start_alpha and $end_alpha: " . displayAlphabets($start_alpha, $end_alpha) . "</p>";
    }
    ?>

</body>
</html>
