<!-- results.php -->
<?php
if (isset($_POST['calculate_area_volume'])) {
    $radius = (float)$_POST['radius'];
    $height = (float)$_POST['height'];

    // Variable functions for area and volume
    $area = function($radius) {
        return pi() * pow($radius, 2);
    };

    $volume = function($radius, $height) {
        return pi() * pow($radius, 2) * $height;
    };

    // Display results
    echo "<h1>Results</h1>";
    echo "<p>Area of Circle: " . $area($radius) . "</p>";
    echo "<p>Volume of Cylinder: " . $volume($radius, $height) . "</p>";
}
?>


